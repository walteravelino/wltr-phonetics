class UnicodeException(Exception):
    pass


class WrongLengthException(Exception):
    pass


class DistanceMetricError(Exception):
    pass


class EmptyStringError(Exception):
    pass
