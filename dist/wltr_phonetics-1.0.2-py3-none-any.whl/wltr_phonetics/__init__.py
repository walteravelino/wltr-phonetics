from .phonetics import (Soundex,
                        Metaphone,
                        MatchingRatingApproach,
                        FuzzySoundex,
                        Lein,
                        RefinedSoundex)

__version__ = '1.0.2'
